﻿namespace Messages.Tests.Models
{
    public class ChannelModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
