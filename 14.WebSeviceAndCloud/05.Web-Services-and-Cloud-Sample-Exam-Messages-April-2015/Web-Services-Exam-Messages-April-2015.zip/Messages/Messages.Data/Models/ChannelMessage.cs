﻿namespace Messages.Data.Models
{
    public class ChannelMessage
    {
        public int Id { get; set; }

        // TODO
    }
}
