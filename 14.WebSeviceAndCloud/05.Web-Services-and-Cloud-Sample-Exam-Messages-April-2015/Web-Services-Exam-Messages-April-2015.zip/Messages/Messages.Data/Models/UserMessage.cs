﻿namespace Messages.Data.Models
{
    public class UserMessage
    {
        public int Id { get; set; }

        // TODO
    }
}
