﻿namespace Messages.Tests.Models
{
    internal class ChannelModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
