﻿namespace BugTracker.Data.Models
{
    public enum BugStatus
    {
        Open,
        InProress,
        Fixed,
        Closed
    }
}
