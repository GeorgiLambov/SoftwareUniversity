﻿namespace BugTracker.Data.Models
{
    public class Comment
    {
        public int Id { get; set; }

        // TODO
    }
}
