﻿namespace BugTracker.Data.Models
{
    public class Bug
    {
        public int Id { get; set; }

        // TODO
    }
}
