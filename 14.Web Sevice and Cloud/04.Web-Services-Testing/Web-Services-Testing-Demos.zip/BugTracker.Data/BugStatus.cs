﻿namespace BugTracker.Data
{
    public enum BugStatus
    {
        New,
        Assigned,
        InProgress,
        Fixed
    }
}
