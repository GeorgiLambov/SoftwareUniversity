<?php
$url = 'http://softuni.bg/';
header('Location: ' . $url, true, 302);
echo $url;