<footer>
    (c) MVC Framework, 2015
</footer>
</body>

</html>