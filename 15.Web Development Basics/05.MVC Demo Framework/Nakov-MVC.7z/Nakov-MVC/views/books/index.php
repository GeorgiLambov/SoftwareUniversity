<p>I am the Books Index view</p>

<h1>List of Books</h1>
...
