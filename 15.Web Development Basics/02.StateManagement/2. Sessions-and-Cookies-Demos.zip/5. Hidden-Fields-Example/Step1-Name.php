<!DOCTYPE html>
<html>
<head>
    <title>Step 1 - Enter Name</title>
</head>
<body>
    <form method="post" action="Step2-Address.php">
        First name: <input type="text" name="first_name" />
        <br />
        Last name: <input type="text" name="last_name" />
        <br />
        <input type="submit" value="Next" />
    </form>
</body>
</html>
