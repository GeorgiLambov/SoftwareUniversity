<h1>Create New Author</h1>

<form method="post" action="/authors/create">
    Name: <input type="text" name="author_name">
    <br/>
    <input type="submit" value="Create">
</form>
