<?php

class BooksController extends BaseController {
    public function onInit() {
        $this->title = "Books";
    }

    public function index() {
    }
}
