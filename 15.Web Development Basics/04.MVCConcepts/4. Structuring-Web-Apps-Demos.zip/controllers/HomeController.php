<?php

class HomeController extends BaseController {
    protected function onInit() {
        $this->title = 'Welcome';
    }
}
