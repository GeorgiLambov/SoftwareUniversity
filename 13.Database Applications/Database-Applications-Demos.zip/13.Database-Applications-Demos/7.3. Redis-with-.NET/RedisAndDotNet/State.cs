﻿namespace RedisAndDotNet
{
    public class State
    {
        public string Value { get; set; }
    }
}
