﻿namespace LinqToMongoDB
{
    public class LogType
    {
        public string Type { get; set; }

        public string State { get; set; }
    }
}
