# Database Applications
Repository for the Database Applications course @ SoftUni https://softuni.bg/courses/database-applications/