﻿namespace Task5
{
    public class Constants
    {
        public const string ConnetionString = "mongodb://localhost";
        public const string DbName = "Reports";
        public const string BaseColectionName = "SalesByProductReports";
        public const string Dbpath = @"c:\data\db";
        public const string ReportsFolder = @"..\..\..\OutputFiles\SqlToJson\reports";
    }
}
